package adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import insta.pet.instapet.R;
import pojo.Mascotaa;

public class adapterMascotaa extends RecyclerView.Adapter<adapterMascotaa.viewholdermascotas> {

    List<Mascotaa> mascotaaList;

    public adapterMascotaa(List<Mascotaa> mascotaaList) {
        this.mascotaaList = mascotaaList;
    }

    @NonNull
    @Override
    public viewholdermascotas onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.avisos_adopcion,parent,false);
        viewholdermascotas holder = new viewholdermascotas(v);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull viewholdermascotas holder, int position) {

        Mascotaa ms = mascotaaList.get(position);

        holder.Rc_nombre.setText(ms.getNombrePerro());
        holder.Rc_descripcion.setText(ms.getDescripcion());
        holder.Rc_raza.setText(ms.getRaza());
        holder.Rc_sexo.setText(ms.getSexo());                //DUDOSO
        holder.Rc_ubicacion.setText(ms.getUbicacion());
    }

    @Override
    public int getItemCount() {
        return mascotaaList.size();
    }

    public class viewholdermascotas extends RecyclerView.ViewHolder {

        TextView Rc_nombre, Rc_sexo, Rc_descripcion, Rc_ubicacion, Rc_raza;



        public viewholdermascotas(@NonNull View itemView) {
            super(itemView);

            Rc_nombre = itemView.findViewById(R.id.Rc_nombre);
            Rc_sexo = itemView.findViewById(R.id.Rc_sexo);
            Rc_descripcion = itemView.findViewById(R.id.Rc_descripcion);
            Rc_ubicacion = itemView.findViewById(R.id.Rc_ubicacion);
            Rc_raza = itemView.findViewById(R.id.Rc_raza);


        }
    }
}
