package insta.pet.instapet;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Adapter;
import android.widget.LinearLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import adapter.adapterMascotaa;
import pojo.Mascotaa;

public class Rc_mascotas extends AppCompatActivity {

    DatabaseReference ref;
    ArrayList<Mascotaa> list;
    RecyclerView rv;
    SearchView searchView;

    adapterMascotaa adapter;
    LinearLayoutManager lm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rc_mascotas);

        ref = FirebaseDatabase.getInstance().getReference().child("DatosPerro");
        rv = findViewById(R.id.rv);
        searchView = findViewById(R.id.buscador);
        lm = new LinearLayoutManager(this);
        rv.setLayoutManager(lm);
        list = new ArrayList<>();
        adapter = new adapterMascotaa(list);
        rv.setAdapter(adapter);


        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if(dataSnapshot.exists()){

                        for (DataSnapshot snapshot : dataSnapshot.getChildren());{
                            Mascotaa ms =  dataSnapshot.getValue(Mascotaa.class);
                            list.add(ms);


                    }
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}