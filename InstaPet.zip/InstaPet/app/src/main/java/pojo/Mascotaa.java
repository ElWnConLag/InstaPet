package pojo;

public class Mascotaa {

    private String descripcion;
    private String nombrePerro;

    private String raza;

    private String sexo;

    private String ubicacion;

    public Mascotaa() {
    }

    public Mascotaa(String descripcion, String nombrePerro, String raza, String sexo, String ubicacion) {

        this.descripcion = descripcion;
        this.nombrePerro = nombrePerro;
        this.raza = raza;
        this.sexo = sexo;
        this.ubicacion = ubicacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombrePerro() {
        return nombrePerro;
    }

    public void setNombrePerro(String nombrePerro) {
        this.nombrePerro = nombrePerro;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }
}
